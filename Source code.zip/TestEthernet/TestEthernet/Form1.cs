﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Net;
using System.Net.NetworkInformation;

namespace TestEthernet
{
    public partial class Form1 : Form
    {
        info inf;

        public Form1()
        {
            InitializeComponent();

            // запуск таймера
            ethernetTimer.Start();
        }

        #region Events
        // происходит при каждой загрузке формы
        private void Form1_Load(object sender, EventArgs e)
        {
            SetBorderRadius();
            ethernetCheck.BackColor = Color.Gray;
            SetHint(true);
            LoadInterface();
        }

        // происходит до закрытия формы
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            ethernetTimer.Stop();
        }

        // таймер; срабатывает каждый промежуток времени (свойство Interval)
        private void ethernetTimer_Tick(object sender, EventArgs e)
        {
            // каждый временной промежуток проверяем подключение к интернету
            bool connection = CheckConnection();
            if (connection == true)
            {
                checkHostButton.Enabled = true;
                toolTip.SetToolTip(checkHostButton, "Отправить запрос на указанный сервер");
                ethernetCheck.BackColor = Color.Green;
            }
            else
            {
                checkHostButton.Enabled = false;
                toolTip.SetToolTip(checkHostButton, "Невозможно выполнить, т.к. нет подключения к интернету");
                ethernetCheck.BackColor = Color.Red;
            }
        }

        // событие при наведении мыши на PictureBox;
        // в зависимости от цвета контролла выводит то или иное сообщение
        private void ethernetCheck_MouseMove(object sender, MouseEventArgs e)
        {
            string ErrorMsg = "Отстуствует подключение к сети. Проверьте настройки Вашего сетевого подключения.";
            string SuccessMsg = "Подключение установлено";

            // условия на неравенства сообщений нужны для того, чтоб подсказка контролла не моргала каждую секунду
            if (ethernetCheck.BackColor == Color.Red)
            {
                if (toolTip.GetToolTip(ethernetCheck) != ErrorMsg)
                {
                    toolTip.SetToolTip(ethernetCheck, ErrorMsg);
                }
            }
            if (ethernetCheck.BackColor == Color.Green)
            {
                if (toolTip.GetToolTip(ethernetCheck) != SuccessMsg)
                {
                    toolTip.SetToolTip(ethernetCheck, SuccessMsg);
                }
            }
        }

        // сработает, когда контролл станет активным элементом управления
        private void hostBox_Enter(object sender, EventArgs e)
        {
            SetHint(false);
        }

        // сработает, когда контролл перестанет быть активным элементом управления
        private void hostBox_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(hostBox.Text))
            {
                SetHint(true);
            }
        }

        // при клике на кнопку Проверить в блоке "Проверка ответа сервера"
        private void checkHostButton_Click(object sender, EventArgs e)
        {

            // TODO: проверка на цвет текста - это просто жесть. Надо придумать что-нибудь другое
            // TODO: а так же нужна валидация на правильность ввода
            if (hostBox.ForeColor == Color.Gray)
            {
                MessageBox.Show("Для проверки необходимо указать полный адрес!", "Ошибка");
            }
            else
            {

                serverResponseBox.Text = SendingMessageToServer(hostBox.Text);
            }
        }

        //при клике обновить
        private void reload_Click(object sender, EventArgs e)
        {
            LoadInterface();
        }

        //срабатывает при изменении адаптера и обновляет информацию
        private void network_interface_SelectedIndexChanged(object sender, EventArgs e)
        {
            var temp = inf.list[network_interface.SelectedIndex];
            interface_info.Text =
                "Interface Type: ...................................................." + temp.interface_type +
                "\r\nMac address: ......................................................." + temp.mac_address +
                "\r\nOperational Status: .............................................." + temp.operational_status +
                "\r\nIp Version: ..........................................................." + temp.ip_version +
                "\r\nDNS suffix: .........................................................." + temp.dns_suffix +
                "\r\nMTU: .................................................................." + temp.mtu +
                "\r\nDNS enabled: ....................................................." + temp.dns_enabled +
                "\r\nDynamically configured DNS: ............................." + temp.dynamically_configured_dns +
                "\r\nReceive only: ......................................................" + temp.receive_only +
                "\r\nMulticast: ............................................................" + temp.multicast +
                "\r\nIPv4: ..................................................................." + temp.ipv4;
        }

        #endregion

        #region Handlers
        // устанавливает круглую форму для PictureBox
        private void SetBorderRadius()
        {
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, ethernetCheck.Width, ethernetCheck.Height);
            Region reg = new Region(path);
            ethernetCheck.Region = reg;
        }

        // проверка подключения к интернету; для большей гарантии успеха
        // подключение к интернету проверяется двумя способами
        private bool CheckConnection()
        {
            return CheckOne() && CheckTwo();
        }

        // первый способ проверки подключения к интернету
        private bool CheckOne()
        {
            if (!NetworkInterface.GetIsNetworkAvailable())
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        // второй способ проверки подключения к интернету
        private bool CheckTwo()
        {
            // подробнее об этом способе проверки читать в https://windowsnotes.ru/other/kak-windows-opredelyaet-podklyuchenie-k-internetu/
            string url = "www.microsoft.com";
            string checkIP = "131.107.255.255";
            try
            {
                IPHostEntry entry = Dns.GetHostEntry(url);
                if (entry.AddressList.Length == 0)
                {
                    return false;
                }
                else
                {
                    if (!entry.AddressList[0].ToString().Equals(checkIP))
                    {
                        return true;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }

        // устанавливает в поле ввода сайта подсказку
        private void SetHint(bool IsShow)
        {
            // параметр IsShow определяет, показывать подсказку или нет
            if (IsShow == true)
            {
                hostBox.Text = "Введите адрес в формате 'http://...'";
                hostBox.ForeColor = Color.Gray;
            }
            else
            {
                hostBox.Text = null;
                hostBox.ForeColor = Color.Black;
            }
        }

        // отправить запрос на указанный сайт
        private string SendingMessageToServer(string url)
        {
            try
            {
                WebRequest request = WebRequest.Create(url);
                WebResponse response = request.GetResponse();
                WebHeaderCollection whc = response.Headers;

                var headers = Enumerable.Range(0, whc.Count).Select(p =>
                {
                    return new
                    {
                        Key = whc.GetKey(p),
                        Names = whc.GetValues(p)
                    };
                });

                string messageServer =
                    "Целевой URL: " + request.RequestUri + ";" + Environment.NewLine +
                    "Тип запроса: " + request.Method + ";" + Environment.NewLine +
                    "Тип полученных данных: " + response.ContentType + ";" + Environment.NewLine +
                    "Заголовки: ";
                foreach (var item in headers)
                {
                    messageServer += Environment.NewLine + "    " + item.Key + ":";
                    foreach (var n in item.Names)
                        messageServer += ' ' + n + ";";
                }

                return messageServer;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка");
                return null;
            }
        }
        
        //обновляет список адаптеров
        private void LoadInterface()
        {
            network_interface.Items.Clear();
            interface_info.Text = "";
            inf = new info();
            inf.GetInfo();

            if (inf.list.Count == 0)
            {
                interface_info.Text = "Нет доступных адаптеров";
                return;
            }
            foreach (var item in inf.list)
            {
                network_interface.Items.Add(item.name);
            }
            network_interface.SelectedIndex = 0;
        }

        #endregion
    }
}
