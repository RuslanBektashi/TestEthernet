﻿namespace TestEthernet
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.serverResponseBox = new System.Windows.Forms.TextBox();
            this.checkHostButton = new System.Windows.Forms.Button();
            this.hostBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.network_interface = new System.Windows.Forms.ComboBox();
            this.ethernetTimer = new System.Windows.Forms.Timer(this.components);
            this.ethernetCheck = new System.Windows.Forms.PictureBox();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.reload = new System.Windows.Forms.Button();
            this.interface_info = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ethernetCheck)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.serverResponseBox);
            this.groupBox2.Controls.Add(this.checkHostButton);
            this.groupBox2.Controls.Add(this.hostBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.Location = new System.Drawing.Point(93, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(729, 292);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Проверка ответа сервера";
            // 
            // serverResponseBox
            // 
            this.serverResponseBox.Location = new System.Drawing.Point(9, 100);
            this.serverResponseBox.Multiline = true;
            this.serverResponseBox.Name = "serverResponseBox";
            this.serverResponseBox.ReadOnly = true;
            this.serverResponseBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.serverResponseBox.Size = new System.Drawing.Size(708, 171);
            this.serverResponseBox.TabIndex = 3;
            // 
            // checkHostButton
            // 
            this.checkHostButton.Location = new System.Drawing.Point(574, 22);
            this.checkHostButton.Name = "checkHostButton";
            this.checkHostButton.Size = new System.Drawing.Size(143, 28);
            this.checkHostButton.TabIndex = 2;
            this.checkHostButton.Text = "Проверить";
            this.checkHostButton.UseVisualStyleBackColor = true;
            this.checkHostButton.Click += new System.EventHandler(this.checkHostButton_Click);
            // 
            // hostBox
            // 
            this.hostBox.Location = new System.Drawing.Point(56, 25);
            this.hostBox.MaximumSize = new System.Drawing.Size(512, 38);
            this.hostBox.MinimumSize = new System.Drawing.Size(512, 28);
            this.hostBox.Name = "hostBox";
            this.hostBox.Size = new System.Drawing.Size(512, 23);
            this.hostBox.TabIndex = 1;
            this.hostBox.Enter += new System.EventHandler(this.hostBox_Enter);
            this.hostBox.Leave += new System.EventHandler(this.hostBox_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 28);
            this.label1.MaximumSize = new System.Drawing.Size(44, 30);
            this.label1.MinimumSize = new System.Drawing.Size(44, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Хост:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(99, 316);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Сетевой адаптер:";
            // 
            // network_interface
            // 
            this.network_interface.FormattingEnabled = true;
            this.network_interface.Location = new System.Drawing.Point(241, 316);
            this.network_interface.Name = "network_interface";
            this.network_interface.Size = new System.Drawing.Size(434, 21);
            this.network_interface.TabIndex = 4;
            this.network_interface.SelectedIndexChanged += new System.EventHandler(this.network_interface_SelectedIndexChanged);
            // 
            // ethernetTimer
            // 
            this.ethernetTimer.Interval = 1000;
            this.ethernetTimer.Tick += new System.EventHandler(this.ethernetTimer_Tick);
            // 
            // ethernetCheck
            // 
            this.ethernetCheck.BackColor = System.Drawing.SystemColors.Control;
            this.ethernetCheck.Location = new System.Drawing.Point(26, 23);
            this.ethernetCheck.Name = "ethernetCheck";
            this.ethernetCheck.Size = new System.Drawing.Size(40, 40);
            this.ethernetCheck.TabIndex = 3;
            this.ethernetCheck.TabStop = false;
            this.ethernetCheck.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ethernetCheck_MouseMove);
            // 
            // reload
            // 
            this.reload.Location = new System.Drawing.Point(681, 312);
            this.reload.Name = "reload";
            this.reload.Size = new System.Drawing.Size(129, 27);
            this.reload.TabIndex = 7;
            this.reload.Text = "Обновить";
            this.reload.UseVisualStyleBackColor = true;
            this.reload.Click += new System.EventHandler(this.reload_Click);
            // 
            // interface_info
            // 
            this.interface_info.Location = new System.Drawing.Point(102, 349);
            this.interface_info.Multiline = true;
            this.interface_info.Name = "interface_info";
            this.interface_info.ReadOnly = true;
            this.interface_info.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.interface_info.Size = new System.Drawing.Size(708, 110);
            this.interface_info.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(829, 471);
            this.Controls.Add(this.interface_info);
            this.Controls.Add(this.reload);
            this.Controls.Add(this.ethernetCheck);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.network_interface);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Тестирование Ethernet";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ethernetCheck)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox hostBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox serverResponseBox;
        private System.Windows.Forms.Button checkHostButton;
        private System.Windows.Forms.Timer ethernetTimer;
        private System.Windows.Forms.PictureBox ethernetCheck;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox network_interface;
        private System.Windows.Forms.Button reload;
        private System.Windows.Forms.TextBox interface_info;
    }
}

