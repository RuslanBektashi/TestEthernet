﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Net;

namespace TestEthernet
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    class NetworkInterfaceInfo
    {
        public string name;
        public string interface_type;
        public string mac_address;
        public string operational_status;
        public string ip_version;
        public string dns_suffix;
        public string mtu;
        public string dns_enabled;
        public string dynamically_configured_dns;
        public string receive_only;
        public string multicast;
        public string ipv4;
    }

    class info
    {
        public List<NetworkInterfaceInfo> list = new List<NetworkInterfaceInfo>();

        public void GetInfo()
        {
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();

            foreach (NetworkInterface adapter in nics)
            {
                if (adapter.NetworkInterfaceType == NetworkInterfaceType.Ethernet)
                {
                    IPInterfaceProperties properties = adapter.GetIPProperties();

                    var temp = new NetworkInterfaceInfo();
                    temp.name = adapter.Description;
                    temp.interface_type = adapter.NetworkInterfaceType.ToString();
                    temp.mac_address = adapter.GetPhysicalAddress().ToString();
                    temp.operational_status = adapter.OperationalStatus.ToString();

                    string versions = "";
                    if (adapter.Supports(NetworkInterfaceComponent.IPv4))
                    {
                        versions = "IPv4";
                    }
                    if (adapter.Supports(NetworkInterfaceComponent.IPv6))
                    {
                        if (versions.Length > 0)
                        {
                            versions += " ";
                        }
                        versions += "IPv6";
                    }
                    if (versions == "")
                        temp.ip_version = "none";
                    else
                        temp.ip_version = versions;

                    temp.dns_suffix = properties.DnsSuffix;

                    if (adapter.Supports(NetworkInterfaceComponent.IPv4))
                        temp.mtu = properties.GetIPv4Properties().Mtu.ToString();
                    else
                        temp.mtu = "none";

                    temp.dns_enabled = properties.IsDnsEnabled.ToString();
                    temp.dynamically_configured_dns = properties.IsDynamicDnsEnabled.ToString();
                    temp.receive_only = adapter.IsReceiveOnly.ToString();
                    temp.multicast = adapter.SupportsMulticast.ToString();


                    foreach (UnicastIPAddressInformation ip in properties.UnicastAddresses)
                    {
                        if (ip.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                        {
                            temp.ipv4 = ip.Address.ToString();
                            break;
                        }
                    }
                    list.Add(temp);
                }
            }
        }
    }	
}
